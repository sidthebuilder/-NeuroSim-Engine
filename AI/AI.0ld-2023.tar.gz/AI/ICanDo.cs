using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CharacterModel {

    public interface ICanDo {
        bool Test(/*TODO*/);
    }

}
