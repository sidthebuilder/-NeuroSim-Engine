using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CharacterModel {

    [System.Serializable]
    public struct UtilityModifier {
        public float multiplier;
        public float additive;
    }

}
