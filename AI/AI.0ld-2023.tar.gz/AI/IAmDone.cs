using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CharacterModel {

    public interface IAmDone {
        bool Test(/*TODO*/);
    }

}