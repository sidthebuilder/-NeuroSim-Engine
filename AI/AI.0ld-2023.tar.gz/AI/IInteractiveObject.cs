using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CharacterModel {

    /// <summary>
    /// This represents the ability of an object in the environment to be interacted with by the
    /// characters AI.  This is object as in a gramatical sense, as in subject-object (the character
    /// acting on the object being the subject).
    ///
    /// To work, this interface must be applied to a MonoBehaviour which can be attached to the
    /// interactable object.
    /// </summary>
    /// TODO:  Not sure how I'm going to work this yet!!!
    public class IInteractiveObject {
        // TODO: Everything
    }

}